
package gui.com;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;


public class Course extends javax.swing.JFrame {

 
    public Course() {
        initComponents();
    }

 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        jComboBox2 = new javax.swing.JComboBox<>();
        jComboBox3 = new javax.swing.JComboBox<>();
        jComboBox4 = new javax.swing.JComboBox<>();
        jComboBox5 = new javax.swing.JComboBox<>();
        jComboBox6 = new javax.swing.JComboBox<>();
        jComboBox7 = new javax.swing.JComboBox<>();
        jComboBox8 = new javax.swing.JComboBox<>();
        jComboBox9 = new javax.swing.JComboBox<>();
        jComboBox10 = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jPanel6 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 0));

        jPanel2.setBackground(new java.awt.Color(0, 153, 153));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));

        jPanel3.setBackground(new java.awt.Color(204, 204, 255));
        jPanel3.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 3, true));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel1.setText("Add Students Course");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 427, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(366, 366, 366))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(204, 255, 204));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));

        jTextField2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        jTextField3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        jComboBox1.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "English Foundation ", "Differential and Integral Calculus", "Physics", "Computer Fundamental", "Coordinate Geometry & Vector Analysis", "Electrical Circuits", "Structured Programming Language", "Differential Equations and Special Functions", "Discrete Mathematics", "Object Oriented Programming", "Linear Algebra and Complex Variables", "Data Structures", "Object Oriented Design and Design Patterns", "Bangladesh Culture & Heritage Studies", "Software Engineering", "Electronic Devices and Circuits", "Algorithms", "Basic Statistics and Probability", "Digital Logic Design", "Computer Networks", "Communication Engineering", "Industrial Management and Accountancy", "Numerical Method", "Database Management System", "Cyber and Intellectual Property Laws", "Theory of Computation and Compiler Design", "Computer Architecture", "E-Commerce and Web Programming", "Economics", "Operating System and System Programming", "Microprocessor and Assembly Language", "System Analysis and Design", "Artificial Intelligence", "Digital Signal Processing", "Computer Graphics", "Digital Image Processing", "Microcontroller, Computer Peripherals and Interfacing", "Computational Geometry", "Design of VLSI Circuits and Systems", "Cryptography and Network Security", "Parallel Processing and Distributed System", "Advance Database Management System", "Multimedia System", "Wireless Communication", "Robotics", "Management Information System" }));

        jComboBox2.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "English Foundation ", "Differential and Integral Calculus", "Physics", "Computer Fundamental", "Coordinate Geometry & Vector Analysis", "Electrical Circuits", "Structured Programming Language", "Differential Equations and Special Functions", "Discrete Mathematics", "Object Oriented Programming", "Linear Algebra and Complex Variables", "Data Structures", "Object Oriented Design and Design Patterns", "Bangladesh Culture & Heritage Studies", "Software Engineering", "Electronic Devices and Circuits", "Algorithms", "Basic Statistics and Probability", "Digital Logic Design", "Computer Networks", "Communication Engineering", "Industrial Management and Accountancy", "Numerical Method", "Database Management System", "Cyber and Intellectual Property Laws", "Theory of Computation and Compiler Design", "Computer Architecture", "E-Commerce and Web Programming", "Economics", "Operating System and System Programming", "Microprocessor and Assembly Language", "System Analysis and Design", "Artificial Intelligence", "Digital Signal Processing", "Computer Graphics", "Digital Image Processing", "Microcontroller, Computer Peripherals and Interfacing", "Computational Geometry", "Design of VLSI Circuits and Systems", "Cryptography and Network Security", "Parallel Processing and Distributed System", "Advance Database Management System", "Multimedia System", "Wireless Communication", "Robotics", "Management Information System" }));

        jComboBox3.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "English Foundation ", "Differential and Integral Calculus", "Physics", "Computer Fundamental", "Coordinate Geometry & Vector Analysis", "Electrical Circuits", "Structured Programming Language", "Differential Equations and Special Functions", "Discrete Mathematics", "Object Oriented Programming", "Linear Algebra and Complex Variables", "Data Structures", "Object Oriented Design and Design Patterns", "Bangladesh Culture & Heritage Studies", "Software Engineering", "Electronic Devices and Circuits", "Algorithms", "Basic Statistics and Probability", "Digital Logic Design", "Computer Networks", "Communication Engineering", "Industrial Management and Accountancy", "Numerical Method", "Database Management System", "Cyber and Intellectual Property Laws", "Theory of Computation and Compiler Design", "Computer Architecture", "E-Commerce and Web Programming", "Economics", "Operating System and System Programming", "Microprocessor and Assembly Language", "System Analysis and Design", "Artificial Intelligence", "Digital Signal Processing", "Computer Graphics", "Digital Image Processing", "Microcontroller, Computer Peripherals and Interfacing", "Computational Geometry", "Design of VLSI Circuits and Systems", "Cryptography and Network Security", "Parallel Processing and Distributed System", "Advance Database Management System", "Multimedia System", "Wireless Communication", "Robotics", "Management Information System" }));

        jComboBox4.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "English Foundation ", "Differential and Integral Calculus", "Physics", "Computer Fundamental", "Coordinate Geometry & Vector Analysis", "Electrical Circuits", "Structured Programming Language", "Differential Equations and Special Functions", "Discrete Mathematics", "Object Oriented Programming", "Linear Algebra and Complex Variables", "Data Structures", "Object Oriented Design and Design Patterns", "Bangladesh Culture & Heritage Studies", "Software Engineering", "Electronic Devices and Circuits", "Algorithms", "Basic Statistics and Probability", "Digital Logic Design", "Computer Networks", "Communication Engineering", "Industrial Management and Accountancy", "Numerical Method", "Database Management System", "Cyber and Intellectual Property Laws", "Theory of Computation and Compiler Design", "Computer Architecture", "E-Commerce and Web Programming", "Economics", "Operating System and System Programming", "Microprocessor and Assembly Language", "System Analysis and Design", "Artificial Intelligence", "Digital Signal Processing", "Computer Graphics", "Digital Image Processing", "Microcontroller, Computer Peripherals and Interfacing", "Computational Geometry", "Design of VLSI Circuits and Systems", "Cryptography and Network Security", "Parallel Processing and Distributed System", "Advance Database Management System", "Multimedia System", "Wireless Communication", "Robotics", "Management Information System" }));

        jComboBox5.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jComboBox5.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "English Foundation ", "Differential and Integral Calculus", "Physics", "Computer Fundamental", "Coordinate Geometry & Vector Analysis", "Electrical Circuits", "Structured Programming Language", "Differential Equations and Special Functions", "Discrete Mathematics", "Object Oriented Programming", "Linear Algebra and Complex Variables", "Data Structures", "Object Oriented Design and Design Patterns", "Bangladesh Culture & Heritage Studies", "Software Engineering", "Electronic Devices and Circuits", "Algorithms", "Basic Statistics and Probability", "Digital Logic Design", "Computer Networks", "Communication Engineering", "Industrial Management and Accountancy", "Numerical Method", "Database Management System", "Cyber and Intellectual Property Laws", "Theory of Computation and Compiler Design", "Computer Architecture", "E-Commerce and Web Programming", "Economics", "Operating System and System Programming", "Microprocessor and Assembly Language", "System Analysis and Design", "Artificial Intelligence", "Digital Signal Processing", "Computer Graphics", "Digital Image Processing", "Microcontroller, Computer Peripherals and Interfacing", "Computational Geometry", "Design of VLSI Circuits and Systems", "Cryptography and Network Security", "Parallel Processing and Distributed System", "Advance Database Management System", "Multimedia System", "Wireless Communication", "Robotics", "Management Information System" }));

        jComboBox6.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jComboBox6.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "NULL", "English Foundation ", "Differential and Integral Calculus", "Physics", "Computer Fundamental", "Coordinate Geometry & Vector Analysis", "Electrical Circuits", "Structured Programming Language", "Differential Equations and Special Functions", "Discrete Mathematics", "Object Oriented Programming", "Linear Algebra and Complex Variables", "Data Structures", "Object Oriented Design and Design Patterns", "Bangladesh Culture & Heritage Studies", "Software Engineering", "Electronic Devices and Circuits", "Algorithms", "Basic Statistics and Probability", "Digital Logic Design", "Computer Networks", "Communication Engineering", "Industrial Management and Accountancy", "Numerical Method", "Database Management System", "Cyber and Intellectual Property Laws", "Theory of Computation and Compiler Design", "Computer Architecture", "E-Commerce and Web Programming", "Economics", "Operating System and System Programming", "Microprocessor and Assembly Language", "System Analysis and Design", "Artificial Intelligence", "Digital Signal Processing", "Computer Graphics", "Digital Image Processing", "Microcontroller, Computer Peripherals and Interfacing", "Computational Geometry", "Design of VLSI Circuits and Systems", "Cryptography and Network Security", "Parallel Processing and Distributed System", "Advance Database Management System", "Multimedia System", "Wireless Communication", "Robotics", "Management Information System" }));

        jComboBox7.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Physics  Lab", "Computer Fundamental Lab", "Electrical Circuits Lab", "Structured Programming Language Lab", "Object Oriented Programming Lab", "Software Development Lab I", "Data Structures Lab", "Object Oriented Design and Design Patterns Lab", "Electronic Devices and Circuits Lab", "Algorithms Lab", "Digital Logic Design Lab", "Computer Networks Lab", "Software Development Lab II", "Numerical Method Lab", "Database Management System Lab", "Computer Architecture Lab", "E-Commerce and Web Programming Lab", "Operating System and System Programming Lab", "Microprocessor and Assembly Language Lab", "Software Development Lab III", "Artificial Intelligence Lab", "Digital Signal Processing Lab", "Computer Graphics Lab", "Digital Image Processing Lab", "Microcontroller, Computer Peripherals and Interfacing Lab", "Computational Geometry Lab", "Design of VLSI Circuits and Systems Lab", "Cryptography and Network Security Lab", "Parallel Processing and Distributed System Lab", "Advance Database Management System Lab", "Multimedia System Lab", "Wireless Communication Lab", "Robotics Lab", "Management Information System Lab", "Project or Thesis with Seminar Part I", "Project or Thesis with Seminar Part II", "Project or Thesis with Seminar Part III", " ", " " }));

        jComboBox8.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jComboBox8.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Physics  Lab", "Computer Fundamental Lab", "Electrical Circuits Lab", "Structured Programming Language Lab", "Object Oriented Programming Lab", "Software Development Lab I", "Data Structures Lab", "Object Oriented Design and Design Patterns Lab", "Electronic Devices and Circuits Lab", "Algorithms Lab", "Digital Logic Design Lab", "Computer Networks Lab", "Software Development Lab II", "Numerical Method Lab", "Database Management System Lab", "Computer Architecture Lab", "E-Commerce and Web Programming Lab", "Operating System and System Programming Lab", "Microprocessor and Assembly Language Lab", "Software Development Lab III", "Artificial Intelligence Lab", "Digital Signal Processing Lab", "Computer Graphics Lab", "Digital Image Processing Lab", "Microcontroller, Computer Peripherals and Interfacing Lab", "Computational Geometry Lab", "Design of VLSI Circuits and Systems Lab", "Cryptography and Network Security Lab", "Parallel Processing and Distributed System Lab", "Advance Database Management System Lab", "Multimedia System Lab", "Wireless Communication Lab", "Robotics Lab", "Management Information System Lab", "Project or Thesis with Seminar Part I", "Project or Thesis with Seminar Part II", "Project or Thesis with Seminar Part III" }));

        jComboBox9.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jComboBox9.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Physics  Lab", "Computer Fundamental Lab", "Electrical Circuits Lab", "Structured Programming Language Lab", "Object Oriented Programming Lab", "Software Development Lab I", "Data Structures Lab", "Object Oriented Design and Design Patterns Lab", "Electronic Devices and Circuits Lab", "Algorithms Lab", "Digital Logic Design Lab", "Computer Networks Lab", "Software Development Lab II", "Numerical Method Lab", "Database Management System Lab", "Computer Architecture Lab", "E-Commerce and Web Programming Lab", "Operating System and System Programming Lab", "Microprocessor and Assembly Language Lab", "Software Development Lab III", "Artificial Intelligence Lab", "Digital Signal Processing Lab", "Computer Graphics Lab", "Digital Image Processing Lab", "Microcontroller, Computer Peripherals and Interfacing Lab", "Computational Geometry Lab", "Design of VLSI Circuits and Systems Lab", "Cryptography and Network Security Lab", "Parallel Processing and Distributed System Lab", "Advance Database Management System Lab", "Multimedia System Lab", "Wireless Communication Lab", "Robotics Lab", "Management Information System Lab", "Project or Thesis with Seminar Part I", "Project or Thesis with Seminar Part II", "Project or Thesis with Seminar Part III" }));

        jComboBox10.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jComboBox10.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Physics  Lab", "Computer Fundamental Lab", "Electrical Circuits Lab", "Structured Programming Language Lab", "Object Oriented Programming Lab", "Software Development Lab I", "Data Structures Lab", "Object Oriented Design and Design Patterns Lab", "Electronic Devices and Circuits Lab", "Algorithms Lab", "Digital Logic Design Lab", "Computer Networks Lab", "Software Development Lab II", "Numerical Method Lab", "Database Management System Lab", "Computer Architecture Lab", "E-Commerce and Web Programming Lab", "Operating System and System Programming Lab", "Microprocessor and Assembly Language Lab", "Software Development Lab III", "Artificial Intelligence Lab", "Digital Signal Processing Lab", "Computer Graphics Lab", "Digital Image Processing Lab", "Microcontroller, Computer Peripherals and Interfacing Lab", "Computational Geometry Lab", "Design of VLSI Circuits and Systems Lab", "Cryptography and Network Security Lab", "Parallel Processing and Distributed System Lab", "Advance Database Management System Lab", "Multimedia System Lab", "Wireless Communication Lab", "Robotics Lab", "Management Information System Lab", "Project or Thesis with Seminar Part I", "Project or Thesis with Seminar Part II", "Project or Thesis with Seminar Part III" }));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        jLabel2.setText("Student ID");

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        jLabel3.setText("Semester");

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        jLabel4.setText("Course1");

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        jLabel5.setText("Course2");

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        jLabel6.setText("Course3");

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        jLabel7.setText("Course4");

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        jLabel8.setText("Course5");

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        jLabel9.setText("Course6");

        jLabel10.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        jLabel10.setText("Course7");

        jLabel11.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        jLabel11.setText("Course8");

        jLabel12.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        jLabel12.setText("Course9");

        jLabel13.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        jLabel13.setText("Course10");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(8, 8, 8)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jComboBox9, 0, 154, Short.MAX_VALUE)
                            .addComponent(jComboBox10, 0, 1, Short.MAX_VALUE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTextField2, javax.swing.GroupLayout.DEFAULT_SIZE, 154, Short.MAX_VALUE)
                            .addComponent(jTextField3)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(15, 15, 15)
                                .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox8, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox7, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox6, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox5, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(47, 47, 47))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTextField3, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                    .addComponent(jComboBox2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                    .addComponent(jComboBox3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                    .addComponent(jComboBox4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                    .addComponent(jComboBox5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jComboBox6, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jComboBox7, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jComboBox8, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                    .addComponent(jComboBox9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBox10, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(204, 255, 204));
        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));

        jTable2.setFont(new java.awt.Font("Times New Roman", 0, 11)); // NOI18N
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Semester", "Course1", "Course2", "Course3", "Course4", "Course5", "Course6", "Course7", "Course8", "Course9", "Course10"
            }
        ));
        jScrollPane1.setViewportView(jTable2);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 385, Short.MAX_VALUE)
        );

        jPanel6.setBackground(new java.awt.Color(204, 255, 204));
        jPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));

        jButton1.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jButton1.setText("Search");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jTextField1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jButton2.setText("Refresh");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton4.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jButton4.setText("Show Student Courses");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 162, Short.MAX_VALUE)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(185, 185, 185))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jPanel7.setBackground(new java.awt.Color(204, 255, 204));
        jPanel7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));

        jButton5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton5.setText("Add New");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton6.setText("Update");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton7.setText("Delete");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton8.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton8.setText("Logout");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jButton9.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton9.setText("Back");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jButton9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 43, Short.MAX_VALUE)
                        .addComponent(jButton7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        Staff staffPage = new Staff();
        staffPage.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        int a = JOptionPane.showConfirmDialog(this, "Do you want to logout now?", "Select", JOptionPane.YES_NO_OPTION);
        if (a == 0) {
            this.dispose();
        }
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        int selectedRow = jTable2.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a row to delete.");
            return;
        }

        int confirmDialogResult = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this record?", "Confirm Delete", JOptionPane.YES_NO_OPTION);

        if (confirmDialogResult == JOptionPane.YES_OPTION) {
            try {
                deleteCourse(selectedRow);
                // JOptionPane.showMessageDialog(this, "Deleted Successfully");
            } catch (SQLException | IOException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        }
    }//GEN-LAST:event_jButton7ActionPerformed
       private void deleteCourse(int selectedRow) throws SQLException, IOException {
    Connection con = null;
    PreparedStatement pst = null;

    try {
        con = DriverManager.getConnection("jdbc:mysql://localhost/student_management","root","");

        // Fetch data from the selected row
        String id = jTable2.getValueAt(selectedRow, 0).toString();

        String sql = "DELETE FROM Course WHERE ID=?";
        pst = con.prepareStatement(sql);
        pst.setString(1, id);

        int rowsAffected = pst.executeUpdate();

        // Remove the selected row from jTable2
        DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
        model.removeRow(selectedRow);

        System.out.println("Rows affected in database: " + rowsAffected);

    } catch (SQLException ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
    } finally {
        if (pst != null) {
            pst.close();
        }
        if (con != null) {
            con.close();
        }
    }
}
    
    
    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        int selectedRow = jTable2.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a row to update.");
            return;
        }

        // Fetch data from the selected row
        String id = jTable2.getValueAt(selectedRow, 0).toString();
        String semester = jTable2.getValueAt(selectedRow, 1).toString();
        String course1 = jTable2.getValueAt(selectedRow, 2).toString();
        String course2 = jTable2.getValueAt(selectedRow, 3).toString();
        String course3 = jTable2.getValueAt(selectedRow, 4).toString();
        String course4 = jTable2.getValueAt(selectedRow, 5).toString();
        String course5 = jTable2.getValueAt(selectedRow, 6).toString();
        String course6 = jTable2.getValueAt(selectedRow, 7).toString();
        String course7 = jTable2.getValueAt(selectedRow, 8).toString();
        String course8 = jTable2.getValueAt(selectedRow, 9).toString();
        String course9 = jTable2.getValueAt(selectedRow, 10).toString();
        String course10 = jTable2.getValueAt(selectedRow, 11).toString();

        // Populate form fields with selected data
        jTextField2.setText(id);
        jTextField3.setText(semester);

        // Set other fields accordingly...
        jComboBox1.setSelectedItem(course1);
        jComboBox2.setSelectedItem(course2);
        jComboBox3.setSelectedItem(course3);
        jComboBox4.setSelectedItem(course4);
        jComboBox5.setSelectedItem(course5);
        jComboBox6.setSelectedItem(course6);
        jComboBox7.setSelectedItem(course7);
        jComboBox8.setSelectedItem(course8);
        jComboBox9.setSelectedItem(course9);
        jComboBox10.setSelectedItem(course10);

        try {
            UpdateCourse(selectedRow);
            JOptionPane.showMessageDialog(this, "Updated Successfully");
        } catch (SQLException | IOException ex) {
            Logger.getLogger(Course.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton6ActionPerformed
     public void UpdateCourse(int selectedRow) throws SQLException, IOException {
    Connection con = null;
    PreparedStatement pst = null;

    try {
        con = DriverManager.getConnection("jdbc:mysql://localhost/student_management","root","");

        // Fetch data from the selected row
        String id = jTable2.getValueAt(selectedRow, 0).toString();

        String sql = "UPDATE Course SET Semester=?, Course1=?, Course2=?, Course3=?, Course4=?, "
                + "Course5=?, Course6=?, Course7=?, Course8=?, Course9=?, Course10=? WHERE ID=?";
        pst = con.prepareStatement(sql);

        pst.setString(1, jTextField3.getText());  // Assuming jTextField3 is for Semester
        pst.setString(2, (String) jComboBox1.getSelectedItem());
        pst.setString(3, (String) jComboBox2.getSelectedItem());
        pst.setString(4, (String) jComboBox3.getSelectedItem());
        pst.setString(5, (String) jComboBox4.getSelectedItem());
        pst.setString(6, (String) jComboBox5.getSelectedItem());
        pst.setString(7, (String) jComboBox6.getSelectedItem());
        pst.setString(8, (String) jComboBox7.getSelectedItem());
        pst.setString(9, (String) jComboBox8.getSelectedItem());
        pst.setString(10, (String) jComboBox9.getSelectedItem());
        pst.setString(11, (String) jComboBox10.getSelectedItem());
        pst.setString(12, id);

        int rowsAffected = pst.executeUpdate();

        // Update jTable2
        DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
        model.setValueAt(jTextField3.getText(), selectedRow, 1);
        model.setValueAt((String) jComboBox1.getSelectedItem(), selectedRow, 2);
        model.setValueAt((String) jComboBox2.getSelectedItem(), selectedRow, 3);
        model.setValueAt((String) jComboBox3.getSelectedItem(), selectedRow, 4);
        model.setValueAt((String) jComboBox4.getSelectedItem(), selectedRow, 5);
        model.setValueAt((String) jComboBox5.getSelectedItem(), selectedRow, 6);
        model.setValueAt((String) jComboBox6.getSelectedItem(), selectedRow, 7);
        model.setValueAt((String) jComboBox7.getSelectedItem(), selectedRow, 8);
        model.setValueAt((String) jComboBox8.getSelectedItem(), selectedRow, 9);
        model.setValueAt((String) jComboBox9.getSelectedItem(), selectedRow, 10);
        model.setValueAt((String) jComboBox10.getSelectedItem(), selectedRow, 11);

        System.out.println("Rows affected in database: " + rowsAffected);

    } catch (SQLException ex) {
        ex.printStackTrace(); // Print the exception stack trace
        JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
    } finally {
        if (pst != null) {
            pst.close();
        }
        if (con != null) {
            con.close();
        }
    }
}
    
    
    
    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        if (jTextField2.getText().length() == 0 ||
            jTextField3.getText().length() == 0 ||
            jComboBox1.getItemCount() == 0 ||
            jComboBox2.getItemCount() == 0 ||
            jComboBox3.getItemCount() == 0 ||
            jComboBox4.getItemCount() == 0 ||
            jComboBox5.getItemCount() == 0 ||
            jComboBox6.getItemCount() == 0 ||
            jComboBox7.getItemCount() == 0 ||
            jComboBox8.getItemCount() == 0 ||
            jComboBox9.getItemCount() == 0 ||
            jComboBox10.getItemCount() == 0) {
            JOptionPane.showMessageDialog(this, "Please fill all course data");
        } else {
            try {
                InsertNewCourse();
                JOptionPane.showMessageDialog(this, "Added Successfully");
            } catch (SQLException | IOException ex) {
                Logger.getLogger(Course.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_jButton5ActionPerformed
    private void InsertNewCourse() throws SQLException, IOException {
    Connection con = null;
    PreparedStatement pst = null;

    try {
        con = DriverManager.getConnection("jdbc:mysql://localhost/student_management","root","");

        String sql = "INSERT INTO Course (ID, Semester, Course1, Course2, Course3,Course4, Course5, Course6, "
                + "Course7, Course8, Course9, Course10) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?)";
        pst = con.prepareStatement(sql);

        pst.setString(1, jTextField2.getText());  // Assuming jTextField2 is for CourseID
        pst.setString(2, jTextField3.getText());  // Assuming jTextField3 is for CourseName
        pst.setString(3, (String) jComboBox1.getSelectedItem());
        pst.setString(4, (String) jComboBox2.getSelectedItem());
        pst.setString(5, (String) jComboBox3.getSelectedItem());
        pst.setString(6, (String) jComboBox4.getSelectedItem());
        pst.setString(7, (String) jComboBox5.getSelectedItem());
        pst.setString(8, (String) jComboBox6.getSelectedItem());
        pst.setString(9, (String) jComboBox7.getSelectedItem());
        pst.setString(10, (String) jComboBox8.getSelectedItem());
        pst.setString(11, (String) jComboBox9.getSelectedItem());
        pst.setString(12, (String) jComboBox10.getSelectedItem());

         int rowsAffected = pst.executeUpdate();

        // Update jTable2
        DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
        Object[] row = {
            jTextField2.getText(), jTextField3.getText(),
            (String) jComboBox1.getSelectedItem(),
            (String) jComboBox2.getSelectedItem(),
            (String) jComboBox3.getSelectedItem(),
            (String) jComboBox4.getSelectedItem(),
            (String) jComboBox5.getSelectedItem(),
            (String) jComboBox6.getSelectedItem(),
            (String) jComboBox7.getSelectedItem(),
            (String) jComboBox8.getSelectedItem(),
            (String) jComboBox9.getSelectedItem(),
            (String) jComboBox10.getSelectedItem()
        };
        model.insertRow(0, row);

        System.out.println("Rows affected in database: " + rowsAffected);

    } catch (SQLException ex) {
        ex.printStackTrace(); // Print the exception stack trace
        JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
    } finally {
        if (pst != null) {
            pst.close();
        }
        if (con != null) {
            con.close();
        }
    }
}
    
    
    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        try {
            ShowStudentCourses();
        } catch (SQLException | IOException ex) {
            Logger.getLogger(Course.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton4ActionPerformed
    
     private void ShowStudentCourses() throws SQLException, IOException {
    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

    try {
        con = DriverManager.getConnection("jdbc:mysql://localhost/student_management","root","");

        String sql = "SELECT * FROM Course";
        pst = con.prepareStatement(sql);
        rs = pst.executeQuery();

        // Clear existing rows in jTable2
        DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
        model.setRowCount(0);

        while (rs.next()) {
            Object[] row = {
                rs.getString("ID"),
                rs.getString("Semester"),
                rs.getString("Course1"),
                rs.getString("Course2"),
                rs.getString("Course3"),
                rs.getString("Course4"),
                rs.getString("Course5"),
                rs.getString("Course6"),
                rs.getString("Course7"),
                rs.getString("Course8"),
                rs.getString("Course9"),
                rs.getString("Course10")
            };
            model.addRow(row);
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
    } finally {
        if (rs != null) {
            rs.close();
        }
        if (pst != null) {
            pst.close();
        }
        if (con != null) {
            con.close();
        }
    }
}
    
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        clearFormFields();
        loadDataIntoTable();
    }//GEN-LAST:event_jButton2ActionPerformed
private void clearFormFields() {
    jTextField2.setText("");
    jTextField3.setText("");
    jComboBox1.setSelectedIndex(0);
    jComboBox2.setSelectedIndex(0);
    jComboBox3.setSelectedIndex(0);
    jComboBox4.setSelectedIndex(0);
    jComboBox5.setSelectedIndex(0);
    jComboBox6.setSelectedIndex(0);
    jComboBox7.setSelectedIndex(0);
    jComboBox8.setSelectedIndex(0);
    jComboBox9.setSelectedIndex(0);
    jComboBox10.setSelectedIndex(0);
}
private void loadDataIntoTable() {
    // Fetch data from the database and update the jTable1 model
    try {
        DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
        model.setRowCount(0); // Clear existing rows
  
    } catch (Exception ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error loading data into table: " + ex.getMessage());
    }
}
    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        String searchId = jTextField1.getText().trim();

        if (searchId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a Student ID for search.");
            return;
        }

        try {
            searchStudent(searchId);
        } catch (SQLException ex) {
            Logger.getLogger(Staff.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton1ActionPerformed
 
    
    public void searchStudent(String searchId) throws SQLException {
    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

    try {
        con = DriverManager.getConnection("jdbc:mysql://localhost/student_management","root","");

        String sql = "SELECT * FROM Course WHERE ID=?";
        pst = con.prepareStatement(sql);
        pst.setString(1, searchId);

        rs = pst.executeQuery();

        DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
        model.setRowCount(0);  // Clear existing rows in jTable1

        while (rs.next()) {
            // Populate the form fields with the search result
            jTextField1.setText(rs.getString("ID"));
            //jTextField2.setText(rs.getString("Name"));
            // Set other fields accordingly...

            // Populate the jTable1 with the found student
            Object[] row = {
                rs.getString("ID"),
                rs.getString("Semester"),
                rs.getString("Course1"),
                rs.getString("Course2"),
                rs.getString("Course3"),
                rs.getString("Course4"),
                rs.getString("Course5"),
                rs.getString("Course6"),
                rs.getString("Course7"),
                rs.getString("Course8"),
                rs.getString("Course9"),
                rs.getString("Course10")
            };
            model.addRow(row);
        }

        if (model.getRowCount() > 0) {
            JOptionPane.showMessageDialog(this, "Student found.");
        } else {
            JOptionPane.showMessageDialog(this, "Student not found.");
        }

    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
    } finally {
        if (rs != null) {
            rs.close();
        }
        if (pst != null) {
            pst.close();
        }
        if (con != null) {
            con.close();
        }
    }
}
  
    
    
   
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Course().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox10;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JComboBox<String> jComboBox4;
    private javax.swing.JComboBox<String> jComboBox5;
    private javax.swing.JComboBox<String> jComboBox6;
    private javax.swing.JComboBox<String> jComboBox7;
    private javax.swing.JComboBox<String> jComboBox8;
    private javax.swing.JComboBox<String> jComboBox9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    // End of variables declaration//GEN-END:variables

    
}
